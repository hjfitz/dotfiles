#!/bin/sh
state=$(mpc | egrep "playing|paused" | sed 's/\W//g' | sed 's/[0-9]//g')
echo $state
