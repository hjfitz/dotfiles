require("bashinvk")
a = bash_invokr("uptime.sh")
print(a)
