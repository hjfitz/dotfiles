function bash_invokr(script)
    upout = os.execute("bash " .. script)
    return upout
end
