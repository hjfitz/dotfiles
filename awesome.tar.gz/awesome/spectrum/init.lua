function bash_invoke(script)
    scripet = script .. ".sh"
    return scripet
end
