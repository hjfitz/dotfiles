# spectrum
Modular status-bar information scripting for Awesome WM
