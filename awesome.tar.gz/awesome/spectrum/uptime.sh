#!/bin/bash

upt=$(uptime | cut -d ' ' -f2)
echo $upt
