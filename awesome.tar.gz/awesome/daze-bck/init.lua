require("daze.layout")
module("daze")
