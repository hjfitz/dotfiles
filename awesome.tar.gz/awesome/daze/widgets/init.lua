require("daze.widgets.calendar")
require("daze.widgets.mpd")
require("daze.widgets.net")
require("daze.widgets.sys")
module("daze.widgets")

