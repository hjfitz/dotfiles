require("spectrum")
print(bash_invoke("uptime"))
